// threading part header
//author @CésarCollé
// 20 / 09 / 2016

#ifndef THREADING_PART_H
#define THREADING_PART_H

#include "../inc/launcher_version.h"

void create_single_thread(grid* map);
void create_threads(grid* );
void multiple_threads(grid * map);

#endif
