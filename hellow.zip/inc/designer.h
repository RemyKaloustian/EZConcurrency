//
// Created by caesar on 10/8/16.
//

#ifndef EZCONCURRENCY_DESIGNER_H
#define EZCONCURRENCY_DESIGNER_H
#include "../inc/elements.h"
void draw_entity(grid *map, int x, int y);
void delete_entity(grid *map, int x, int y);
void affic_grid(grid *map);

#endif //EZCONCURRENCY_DESIGNER_H
