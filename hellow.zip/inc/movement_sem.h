#ifndef MOVEMENT_SEM_H
#define MOVEMENT_SEM_H



void * automata_synchronized_sem(void * ptr);

#endif
