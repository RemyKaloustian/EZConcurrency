#ifndef  MONITOR_MOVEMENT
#define  MONITOR_MOVEMENT


void *automata_synchronized_monitor(void *param_ptr_data);
#endif
